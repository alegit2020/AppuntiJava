/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizio3;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author a.galli
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        Forma r1 = new Equilatero(1, "Rosso"); // r1 ed...
        Forma r2 = new Equilatero(1, "Rosso"); // ..r2 "contano" 1
        Forma r3 = new Quadrato(2, "Nero");
        Forma r4 = new Cerchio(2, "Nero");
        
        Set<Forma> set = new HashSet<Forma>();
        set.add(r1);
        set.add(r2);
        set.add(r3);
        set.add(r4);

        RaggruppatoreDiForme gruppo = new RaggruppatoreDiForme();
        Raccoglitore raccolta = gruppo.raggruppa(set);    
        
        System.out.println("\nCerchi list:" + raccolta.getCerchi());
        System.out.println("\nQuadrati list:" + raccolta.getQuadrati());
        System.out.println("\nEqui list:" + raccolta.getEquilateri());
        
/*        for (Forma f:set) {
            System.out.println("\n" + f.getColore());
            System.out.println("\nClasse:" + f.getClass());
            //f.stampa();
            //f.addForma(f);
        }
 */
    }
    
}
