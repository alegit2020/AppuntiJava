package esercizio3;

/**
 *
 * @author a.galli
 */
public class Quadrato extends AbstractForma{

    public Quadrato ( int d , String c){
        super.dimensione = d;
        super.colore = c;
    }

    @Override
    public void accetta(RaggruppatoreDiForme raggruppatore) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

