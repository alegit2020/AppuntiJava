package esercizio3;

public interface Forma {

    public String getColore();

    public int getDimensione();

    public void accetta(RaggruppatoreDiForme raggruppatore);
}
