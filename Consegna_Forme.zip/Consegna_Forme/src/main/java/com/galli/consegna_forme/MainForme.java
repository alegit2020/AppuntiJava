/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

/**
 *
 * @author alexg
 */
public class MainForme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GruppoDiForme gdf = new GruppoDiForme();
        GruppoDiForme cerchi , rettangoli , altriRaggruppamenti;
        cerchi = new GruppoDiForme();
        rettangoli = new GruppoDiForme();
        altriRaggruppamenti = new GruppoDiForme();
        Cerchio c1,c2;
        Rettangolo r1, r2;
        Punto p = new Punto (0,0);
        c1 = new Cerchio ( p,5,"rosso");
        r1 = new Rettangolo (p,4,6,"blu");
        p = new Punto (10,10);
        c2 = new Cerchio ( p,3,"giallo");
        r2 = new Rettangolo (p,2,8,"verde");

        
        gdf.add(c1); gdf.add(r1); gdf.add(c2); gdf.add(r2);
        cerchi.add(c1); cerchi.add(c2);
        rettangoli.add(r1); rettangoli.add(r2);
        
        System.out.println("\nSITUAZIONE");
        System.out.println(gdf);
        //System.out.println(cerchi);
        gdf.trasla(100, 100);
        System.out.println("\nRISULTATO");
        System.out.println(gdf);
        
    }
    
}
