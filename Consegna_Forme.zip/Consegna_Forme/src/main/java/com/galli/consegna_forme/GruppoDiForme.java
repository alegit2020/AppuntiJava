/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author alexg
 */
public class GruppoDiForme{
   private final ArrayList<Forma> elenco;
   
   public GruppoDiForme(){
       elenco = new ArrayList();
   }
   
   //creo questo metodo per mantenere elenco privata
   public void add( Forma o){
       this.elenco.add(o);
   }
   
   public void trasla (int x , int y) {
       for (Forma f : this.elenco) {
           f.trasla(x, y);
       }
       
   }
   
   @Override
   public String toString (){
       StringBuilder sb = new StringBuilder();
       Iterator i = elenco.iterator();
       while (i.hasNext()) {
           //System.out.println("\n"+i.next());
           sb.append("\n");
           sb.append(i.next());
       }
       return sb.toString();
   }
   
   

}
