/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

/**
 *
 * @author alexg
 */
public class Cerchio implements Forma{

    private final int raggio;
    private final Punto centro;
    private final String colore;

    public Cerchio(Punto centro, int raggio, String colore) {
        this.raggio = raggio;
        this.centro = new Punto(centro.getX(), centro.getY());
        this.colore = colore;
    }

    @Override
    public void trasla(int x, int y) {
        this.centro.setX(this.centro.getX() + x);
        this.centro.setY(this.centro.getY() + y);
    }
    
    @Override
    public String toString(){
        //return "è cerchio in " + this.centro;
        return "cerchio: centro:"+this.centro+" raggio:" + this.raggio +" colore:"+this.colore;
    }

    public String getCentro() {
        return this.centro.toString();
    }
}
