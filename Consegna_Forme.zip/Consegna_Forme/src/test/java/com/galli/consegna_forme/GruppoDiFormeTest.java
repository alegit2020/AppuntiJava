/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author a.galli
 */
public class GruppoDiFormeTest {
     @Test
     public void testTrasla_GruppoSemplice(){
        Punto pr = new Punto (1,1);
        Rettangolo r1 = new Rettangolo(pr , 5,7, "rosso");
        Punto pc = new Punto (-1,-3);
        Cerchio c1 = new Cerchio (pc , 4, "blu");
        GruppoDiForme g1 = new GruppoDiForme();
        g1.add(c1);
        g1.add(r1);
        Punto attesoRettangolo = new Punto (1,1);
        Punto attesoCerchio = new Punto (-1,-3);
        assertEquals("errore vertice rettangolo", attesoRettangolo.toString() , r1.getVertice().toString() );
        assertEquals("errore centro cerchio", attesoCerchio.toString() , c1.getCentro().toString() );
        g1.trasla(3, 2);
        attesoRettangolo = new Punto (4,3);
        attesoCerchio = new Punto (2,-1);
        assertEquals("errore traslazine rettangolo", attesoRettangolo.toString() , r1.getVertice().toString() );
        assertEquals("errore traslazine cerchio", attesoCerchio.toString() , c1.getCentro().toString() );
     }       
     
     @Test
     public void testTrasla_GruppoDiGruppi(){
        Punto pr = new Punto (1,1);
        Rettangolo r1 = new Rettangolo(pr , 5,7, "rosso");
        Punto pc = new Punto (-1,-3);
        Cerchio c1 = new Cerchio (pc , 4, "blu");
        GruppoDiForme g1 = new GruppoDiForme();
        g1.add(c1);
        g1.add(r1);
        
        pc = new Punto (-1,2);
        Cerchio c2 = new Cerchio (pc , 2, "blu");
        GruppoDiForme g2 = new GruppoDiForme();
       // g2.add(g1);
        
        Punto attesoRettangolo = new Punto (1,1);
        Punto attesoCerchio = new Punto (-1,-3);
        assertEquals("errore vertice rettangolo", attesoRettangolo.toString() , r1.getVertice().toString() );
        assertEquals("errore centro cerchio", attesoCerchio.toString() , c1.getCentro().toString() );
        g1.trasla(3, 2);
        attesoRettangolo = new Punto (4,3);
        attesoCerchio = new Punto (2,-1);
        assertEquals("errore traslazine rettangolo", attesoRettangolo.toString() , r1.getVertice().toString() );
        assertEquals("errore traslazine cerchio", attesoCerchio.toString() , c1.getCentro().toString() );
     }      
     
}
