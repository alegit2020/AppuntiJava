/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.alex.nettuno_rubrica_cap5;

/**
 *
 * @author alexg
 */
public class VoceAssente extends Exception {
}
