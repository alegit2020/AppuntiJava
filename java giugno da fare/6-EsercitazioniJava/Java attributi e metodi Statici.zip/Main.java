class Main {  
  public static void main(String[] args) {
    Classe1 cl;
    System.out.println("\noggetto Non istanziato...");
    System.out.println("\nk Statico "+ Classe1.k);
    Classe1.taratura(10);
    System.out.println("\nk statico aggiornato "+ Classe1.k);
    System.out.println("\nIstanzio l'oggetto...");
    cl= new Classe1(0);
    System.out.println("\nk Statico "+ cl.k);
    System.out.println("\nj  "+ cl.j);
  }
}