public class Classe1 {
static double k=3;
double j;

  public Classe1(double n){ //costruttore
    j=3+n;
  }

  public static void taratura(double t){
    k=k+t;
  }

}