public class Main {
//public class Olimpiadi {
	public void iscrivi(Atleta a){
		System.out.print("A ");
	}
	public void iscrivi(Corridore C) {
		System.out.print("C ");
	}
	public void iscrivi(Saltatore s) {
		System.out.print("S ");
	}

	public static void main(String args[]) {
	  Main o = new Main();

	  Corridore c = new Corridore();
	  Saltatore s = new Saltatore();
	  Atleta a = new Corridore();
	  a = s;
    //a = c;
	  o.iscrivi(a);
	  o.iscrivi(s);
	  o.iscrivi(c);
    a.gareggia();
    
	}
}