class Saltatore implements Atleta {
   public Saltatore() {}
   public void gareggia(){
         System.out.print("xsalta");
   };
}