interface Atleta {  	//domanda: le interfacce sono classi a tutti gli effetti? 
			//quindi possono anche essere istanziate e usate normalmente?
	void gareggia();
}