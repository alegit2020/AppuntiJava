class Corridore implements Atleta {
	public Corridore() {}
	public void gareggia() {
    System.out.print("xcorr");
  };
}