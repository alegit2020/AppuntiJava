public interface Visitor {

	public void visita(Merce merce);

	public void visita(Scatola scatola);

}
