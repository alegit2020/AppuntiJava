public class Bilancia implements Visitor {

	// classe da completare
	// ...
	private int pesoComplessivo;

	public Bilancia() {
		this.pesoComplessivo = 0;
	}

	public void visita(Merce merce) {
		// da completare
	}

	public void visita(Scatola scatola) {
		// da completare
	}

	public int getPesoComplessivo(Pesabile pesabile) {
		this.pesoComplessivo = 0;
		pesabile.accetta(this);
		return this.pesoComplessivo; 
	}

}
