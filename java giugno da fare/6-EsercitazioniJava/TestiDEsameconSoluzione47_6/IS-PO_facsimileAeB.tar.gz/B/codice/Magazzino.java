import java.util.*;

public class Magazzino {
	private Map<Libro,Integer> libro2quantita;

	private Map<Disco,Integer> disco2quantita;

	public Magazzino() {
		this.libro2quantita = new HashMap<Libro,Integer>();
		this.disco2quantita = new HashMap<Disco,Integer>();
	}

	public void aggiungiDisco(Disco disco, int quantita){
		disco2quantita.put(disco, quantita);
	}

	public void aggiungiLibro(Libro libro, int quantita){
		libro2quantita.put(libro, quantita);
	}

	public int calcolaValoreMagazzino() {
		int valore = 0;
		// DOMANDA 5b: da completare
		return valore;
	}

	public Map<Integer,Set<String>> articoliEconomici(int soglia) {
		// costo -> insieme di codici di articoli con il costo della chiave
		Map<Integer,Set<String>> costo2insiemeCodiceArticoli;
		costo2insiemeCodiceArticoli = new HashMap<Integer,Set<String>>();
		// DOMANDA 5c: da completare
		return costo2insiemeCodiceArticoli;
	}

	public List<Articolo> articoliOrdinatiPerCosto() {
		List<Articolo> listaArticoli = new LinkedList<Articolo>();
		// DOMANDA 5d: 
		return listaArticoli;
	}

}
