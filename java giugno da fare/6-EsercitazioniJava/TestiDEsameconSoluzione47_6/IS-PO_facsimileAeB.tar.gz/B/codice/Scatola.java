import java.util.List;

public class Scatola implements Pesabile {

	// classe da completare con costruttori, 
	// variabili d'istanza e quant'altro 
	// ...
	/** restituisce il peso proprio dell'imballaggio */
	public int getPeso() { /* da completare */ }

	public void accetta(Visitor visitor) { /* da completare */ }

	/** per aggiungere oggetti pesabili all'interno del contenitore */
	public void add(Pesabile pesabile) { /* da completare */}

	/** per ottenere la collezione di oggetti pesabili in questa scatola */
	public List<Pesabile> getOggettiContenuti()	 { /* da completare */}

}
