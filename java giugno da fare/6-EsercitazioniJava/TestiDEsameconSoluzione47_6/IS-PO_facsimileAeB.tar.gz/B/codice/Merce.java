public class Merce implements Pesabile {	

	// classe da completare con costruttori, 
	// variabili d'istanza e quant'altro
	// ... 
	public int getPeso() { /* da completare */ }

	public void accetta(Visitor visitor) { /* da completare */ }

}
