public interface Pesabile {

	/** restituisce il peso proprio di un oggetto pesabile */
	public int getPeso();

	/** accetta la visita da parte di un visitor (vedi dopo) */
	public void accetta(Visitor visitor);

}