public class ImmutableArrayList {

	private Object[] elements;

	public ImmutableArrayList(Object[] elements) {
		this.elements = elements;
	}

	public Object get(int index) {
	   return this.elements[index];
	}

	public int size() {
		return this.elements.length;
	}

	public Iterator iterator() { /* da completare */ }

}
