import java.util.*;

public class Cartella {

	private Set<File> elencoFile;

	private String nome;

	private String proprietario;

	public Cartella(String nome, String proprietario) {
		this.nome = nome;
		this.proprietario = proprietario;
		this.elencoFile = new HashSet<File>();
	}

	public void addFile(File file) { this.elencoFile.add(file); }

	public String getNome() { return nome; }

	public String getProprietario() { return proprietario; }

	public int getDimensione() {
		int dimensione = 0;
		for(File file : this.elencoFile)
			dimensione += file.getDimensione();
		return dimensione;
	}

	public int hashCode() { return this.getNome().hashCode(); }

	public boolean equals(Object obj) {
		Cartella cartella = (Cartella)obj;
		return this.getNome().equals(cartella.getNome());
	}

	public Map<String, Set<File>> proprietario2file(){
		Map<String, Set<File>> proprietario2file = 
			new HashMap<String, Set<File>>();
		for(File file : this.elencoFile) {
			Set<File> files = proprietario2file.get(file.getProprietario());
			if (files == null)
				files = new HashSet<File>();
			files.add(file);
			proprietario2file.put(file.getProprietario(), files);
		}
		return proprietario2file;
	}

}
