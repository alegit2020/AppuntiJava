class ImmutableArrayListIterator implements Iterator {

    private ImmutableArrayList creatore;

    // aggiungere altre variabili di istanze e/o metodi se necessario ...
    ImmutabileArrayListIterator(ImmutableArrayList creatore) {
       this.creatore = creatore;
       // da completare e/o modificare se necessario
    }

    public boolean hasNext() { /* da completare */ }

    public Object next() { /* da completare */ }

}
