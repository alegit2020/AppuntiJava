public class File {

	private String nome;

	private int dimensione;

	private String proprietario;

	public File(String nome, int dimensione, String proprietario) {
		this.nome = nome;
		this.dimensione = dimensione;
		this.proprietario = proprietario;
	}

	public int getDimensione() { return this.dimensione; }

	public String getNome() { return this.nome; }

	public String getProprietario() { return this.proprietario; }

	public int hashCode() { return this.getNome().hashCode(); }

	public boolean equals(Object obj) {
		File file = (File)obj;
		return this.getNome().equals(file.getNome());
	}

}
