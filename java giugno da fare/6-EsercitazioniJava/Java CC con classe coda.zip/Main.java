import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;

class Main {
  public static final int num_max_movimenti = 5;

  public static void main(String[] args) {
    System.out.println("Hello world!");
    int i=0;
    AbstractQueue<Operazione> lista_movimenti = new ArrayBlockingQueue(num_max_movimenti);
    Operazione o,od;

    o = new Operazione('v', 1000 , "07/01/2020");
    lista_movimenti.add(o);
    System.out.print("\n caricato " + lista_movimenti.size());
    o = new Operazione(o.PRELIEVO, 20 , "18/05/2020");
    lista_movimenti.add(o);
    System.out.print("\n caricato " + lista_movimenti.size());
    o = new Operazione(o.PRELIEVO, 880 , "3/05/2020");
    lista_movimenti.add(o);
    System.out.print("\n caricato " + lista_movimenti.size());
    o = new Operazione(o.PRELIEVO, 1 , "9/07/2020");
    lista_movimenti.add(o);
    System.out.print("\n caricato " + lista_movimenti.size());
    o = new Operazione(o.PRELIEVO, 25 , "18/09/2020");
    lista_movimenti.add(o);
    System.out.print("\n caricato " + lista_movimenti.size());

    try{
    o = new Operazione('x', 9 , "18/09/2020");    
    lista_movimenti.add(o);
    }
    catch (Exception e) { 
      System.out.print("\ncoda piena");
      od = lista_movimenti.poll();
      lista_movimenti.add(o);
      System.out.print("\n caricato " + lista_movimenti.size());
    }

    o=lista_movimenti.element();
    o.stampa_operazione();    
    o=lista_movimenti.peek();
    o.stampa_operazione();    
    o=lista_movimenti.poll();
    o.stampa_operazione();    
    o=lista_movimenti.remove();
    o.stampa_operazione();    
    o=lista_movimenti.remove();
    o.stampa_operazione();    
    o=lista_movimenti.remove();
    o.stampa_operazione();    
    o=lista_movimenti.remove();
    o.stampa_operazione();    
    //Operazione[] mov = new Operazione[5];
    //debug..gli obj creati verranno automaticamente liberati
    /*mov[i] = new Operazione('v', 1000 , "07/01/2020");
    mov[i].stampa_operazione();
    i++;
    mov[i] = new Operazione(mov[i].PRELIEVO, 20 , "18/05/2020");
    mov[i].stampa_operazione();
    i++;
    mov[i] = new Operazione('x', 20 , "18/05/2020");
    mov[i].stampa_operazione();
    mov[i] = new Operazione(mov[i].VERSAMENTO, 20 , "18/05/2020");
    mov[i].stampa_operazione();
    */
  }
}