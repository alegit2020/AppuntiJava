public class Operazione {
  //Costanti
  public static final char VERSAMENTO ='V';
  public static final char PRELIEVO ='P';

  //attributi
  private char tipo_movimento;
  private double importo;
  private String data;
  private double numero_op;

  //attributi Statici
  protected static double numero_op_complessive=0;

    /* La classe definisce gli elementi del vettore movimenti mantenuto nella classe CC/Main

    Il metodo stampa_operazione() sempifica la stampa a video del record
    */

    /* Il costruttore è semplice
    prende i parametri e li carica.
    Per esercizio faccio un controllo sul tipo_movimento che è un char trasformato in String ecc...
    */

    public Operazione (char tipo, double importo , String data) {
        /* Faccio un blando controllo dell'input
        tanto per fare esercizio
        */
        String tipoupper = String.valueOf(tipo);
        tipoupper.toUpperCase();
        this.tipo_movimento = tipoupper.charAt(0);
        this.importo = importo;
        this.data=data;
        numero_op_complessive++;
        this.numero_op= numero_op_complessive;
    }

    public void stampa_operazione(){
      if (this.tipo_movimento == VERSAMENTO){
        System.out.print("\nOp "+ this.numero_op + ": Versamento in data "+this.data + " di €" + this.importo);
      }
      else if (this.tipo_movimento == PRELIEVO){
        System.out.print("\nOp "+ this.numero_op + ": Prelievo in data "+this.data + " di €" + this.importo);
      } else {
        System.out.print("\nOp "+ this.numero_op + ": "+ this.tipo_movimento + " in data "+this.data + " di €" + this.importo);
      }
    }
}