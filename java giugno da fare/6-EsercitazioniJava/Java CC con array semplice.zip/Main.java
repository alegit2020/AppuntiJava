class Main {
  public static void main(String[] args) {
    int i=0;
    Operazione[] mov = new Operazione[5];
    System.out.println("Hello world!");
    //debug..gli obj creati verranno automaticamente liberati
    mov[i] = new Operazione('v', 1000 , "07/01/2020");
    mov[i].stampa_operazione();
    i++;
    mov[i] = new Operazione(mov[i].PRELIEVO, 20 , "18/05/2020");
    mov[i].stampa_operazione();
    i++;
    mov[i] = new Operazione('x', 20 , "18/05/2020");
    mov[i].stampa_operazione();
    mov[i] = new Operazione(mov[i].VERSAMENTO, 20 , "18/05/2020");
    mov[i].stampa_operazione();
  }
}