public class C3 extends C2 {
double v3;
  public C3(){
    v3=3;
  }
  public void stampa( ){
    System.out.print("\nmetodo di C3");
  }
}