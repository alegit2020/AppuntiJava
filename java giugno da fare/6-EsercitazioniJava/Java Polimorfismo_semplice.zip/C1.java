public class C1 extends C0 {
double v1;
  public C1(){
    v1=1;
  }
  static public void stampa_abstract( double n){
    System.out.print("\nastratto preso da C0:" + C0.a0 + " e n=" + n);
  }
  public void stampa( ){
    System.out.print("\nmetodo di C1");
  }

}