class Main {  
  public static void main(String[] args) {
    C1 c1 = new C1();
    C2 c2 = new C2();
    C3 c3 = new C3();
    C1 c3bis = new C3();

    System.out.print("\nc1.v1=" + c1.v1);
    System.out.print("\nc2.v1=" + c2.v1 + " c2.v2=" + c2.v2);
    System.out.print("\nc3.v1=" + c3.v1 + " c3.v2=" + c3.v2 + " c3.v3=" + c3.v3);

    //System.out.println("\nc3bis.v1=" + c3bis.v1 + " c3bis.v2=" + c3bis.v2  + " c3bis.v3=" + c3bis.v3); //NOTA : il tipo di c3bis è C1 quindi questa riga darà errore poichè non esistono in C1 le var v2,v3

    //Esempio di polimorfismo
    c1.stampa();
    c2.stampa();
    c3.stampa();
    c3bis.stampa(); //c3bis è tipo C1 ma viene usato il metodo di C3

    C1.stampa_abstract(3);
  }
}