public abstract class C0{
public static double a0=3;

}