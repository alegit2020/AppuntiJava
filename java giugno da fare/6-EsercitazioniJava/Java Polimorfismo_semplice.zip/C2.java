public class C2 extends C1 {
double v2;
  public C2(){
    v2=2;
  }
  public void stampa( ){
    System.out.print("\nmetodo di C2");
  }
}