/*
 * Classe creata per implementare il Design Pattern Adapter di Classe
 */
package projects.precipitazioni.base;

/**
 *
    @author GALLI ALESSANDRO 2574HHHINGINFO
 */
public class VisAdapter extends Precipitazioni{

    public VisAdapter( Precipitazioni p , int i) {
        this.cartaPrecipitazioni = p.cartaPrecipitazioni;
        this.visualizzatore = p.visList.get(i);
        this.visualizzatore.setPrecipitazioni(this); 
    }

    public void aggiornaSchermata(int tempo) {
        this.visualizzatore.aggiornaSchermata(tempo);

    }
}
