package projects.precipitazioni.base;
/*
    @author GALLI ALESSANDRO 2574HHHINGINFO
*/
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Precipitazioni {

        //NOTA ho modificato lo scope da private a protected pre usare l'Adattatore VisAdapter
	protected int[][] cartaPrecipitazioni;
	protected Visualizzatore visualizzatore;
        protected ArrayList<Visualizzatore> visList;
        
	public Precipitazioni () {
		this.cartaPrecipitazioni = new int[20][20];
                this.visList = new ArrayList();
	}

	int[][] getCartaPrecipitazioni() {
		return this.cartaPrecipitazioni;
	}

        public void aggiungiVisualizzatore(Visualizzatore v) {
            this.visList.add(v);
        }
        
        //faccio l'Overload che imposta il Visualizzatore in base ad un intero
        public void setVisualizzatore (int i) {
            this.visualizzatore = this.visList.get(i);
            this.visualizzatore.setPrecipitazioni(this);  //init dell OBJ precipitazioni
        }
        
	public void setVisualizzatore(Visualizzatore v) {
		this.visualizzatore = v;
		v.setPrecipitazioni(this);
	}

        public Visualizzatore getVisualizzatore (int i){
            return this.visList.get(i);
        }
        
	public void notificaAggiornamento(int tempo) {
            //Chiamata originale nell'esercizio - la lascio per confronto
            System.out.println("\nVisualizzatore Richiesto dall'utente:");
            this.visualizzatore.aggiornaSchermata(tempo);
                
            //NUOVA chiamata richiesta dall'Esercizio
            //Utilizzo il Pattern Adapter
            //per semplicità uso il ciclo for per fare le chiamate sullo stesso set di dati (o passo temporale)
            //ma utilizzando ogni volta tutti e 10 i Visualizzatori presenti
            VisAdapter adaptee;
            for (int i=0 ; i<10 ; i++){
                        adaptee = new VisAdapter (this,i);
                        System.out.println("\nVisualizzatore Tipo :" + (i+1));
                        adaptee.aggiornaSchermata(tempo);
            }
        }

	private void calcolaPrecipitazioni(int istanteTemporale){
		for (int i=0; i<this.cartaPrecipitazioni.length; i++)
			for (int j=0; j<this.cartaPrecipitazioni[i].length; j++)
				this.cartaPrecipitazioni[i][j] = (int)(Math.random()*10);
		try { Thread.sleep( 100); }
		catch( InterruptedException e ) {
			e.printStackTrace();
		}
	}

	public void eseguiSimulazione() {
		for (int tempo=0; tempo<10; tempo++) {
			this.calcolaPrecipitazioni(tempo);
			this.notificaAggiornamento(tempo);
		}
	}
}