package esercizio3;

import java.util.ArrayList;

/**
 *
 * @author alexg
 */
public class Equilatero extends AbstractForma{

    public Equilatero ( int d , String c){
        super.dimensione = d;
        super.colore = c;
        super.lista = new ArrayList<Equilatero>();  //il tipo Forma è già dichiarato nella super-classe AbstractForma
    }

    @Override
    public void addForma(Object f){
        this.lista.add( (Equilatero) f );
        System.out.println("\naggiunto Equil");
    }
    
    
    @Override
    public void stampa(){
        System.out.println("Eqqui_");
    }
}

