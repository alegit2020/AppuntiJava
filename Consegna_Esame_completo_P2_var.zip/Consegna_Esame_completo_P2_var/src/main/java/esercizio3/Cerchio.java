package esercizio3;

import java.util.ArrayList;

/**
 *
 * @author alexg
 */
public class Cerchio extends AbstractForma{
   
    public Cerchio ( int d , String c){
        super.dimensione = d;
        super.colore = c;
        super.lista = new ArrayList<Cerchio>();  //il tipo Forma è già dichiarato nella super-classe AbstractForma
    }

    @Override
    public void addForma(Object f){
        this.lista.add( (Cerchio) f );
        System.out.println("\naggiunto cerchio");
    }
    
    @Override
    public void stampa(){
        System.out.println("Cicccerchi_");
    }
}
