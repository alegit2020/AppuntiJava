package esercizio3;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author alexg
 */
public class Quadrato extends AbstractForma{
   
    public Quadrato ( int d , String c){
        super.dimensione = d;
        super.colore = c;
        super.lista = new ArrayList<Quadrato>();  //il tipo Forma è già dichiarato nella super-classe AbstractForma
    }
    
    @Override
    public void addForma(Object f){
        this.lista.add( (Quadrato) f );
        System.out.println("\naggiunto quadra");
    }
    
    @Override
    public void stampa(){
        System.out.println("Quaqqua_");
    }
   
}
