public class VoceAssente extends Exception {
}