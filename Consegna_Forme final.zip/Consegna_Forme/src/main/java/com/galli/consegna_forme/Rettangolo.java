/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

/**
 *
 * @author alexg
 */
public class Rettangolo implements Forma{

    private final int altezza;
    private final int larghezza;
    private final Punto vertice;
    private final String colore;

    public Rettangolo(Punto vertice, int altezza,
            int larghezza, String colore) {
        this.altezza = altezza;
        this.larghezza = larghezza;
        this.vertice = new Punto(vertice.getX(), vertice.getY());
        this.colore = colore;
    }

    @Override
    public void trasla(int x, int y) {
        this.vertice.setX(this.vertice.getX() + x);
        this.vertice.setY(this.vertice.getY() + y);
    }
    @Override
    public String toString(){
        //return "è rettangolo in " + this.vertice;
        return "rettangolo: vertice:"+this.vertice+" altezza:" + this.altezza + " larghezza:"+this.larghezza+" colore:"+this.colore;
    }
    public String getPunto() {
        return this.vertice.toString(); 
    }

}
