/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

import java.lang.System.Logger;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author alexg
 */
public class GruppoDiForme implements Forma{
   private final ArrayList<Forma> elenco;
   
   public GruppoDiForme(){
       elenco = new ArrayList();
   }
   
   //creo questo metodo per mantenere elenco privata
   public void add( Forma o){
       this.elenco.add(o);
   }
   
   @Override
   public String getPunto(){
       StringBuilder sb = new StringBuilder();
       for (Forma f : this.elenco) {
           //System.out.print(f.getPunto());
           sb.append(f.getPunto());
       }

/* NOTA : usando Iterator non riuscivo a accedere a getPunto
       Iterator i = elenco.iterator();
        while (i.hasNext()) {
            System.out.println( i.next());
       }
*/        
        return sb.toString();
   }
   
   @Override
   public void trasla (int x , int y) {
       for (Forma f : this.elenco) {
           f.trasla(x, y);
       }
   }
   
   @Override
   public String toString (){
       StringBuilder sb = new StringBuilder();
       Iterator i = elenco.iterator();
       while (i.hasNext()) {
           //System.out.println("\n"+i.next());
           //sb.append("\n");
           sb.append(i.next());
       }
       return sb.toString();
   }
   
   public void caricaMenoDi10() throws Exception{
    //try {
       int i;
        Punto p = new Punto (0,0);
        Cerchio c;
        for (i = 1 ; i<= 10 ; i++){
            c = new Cerchio (p,1,"bianco");
            this.elenco.add(i,c);  //questo add @throws IndexOutOfBoundsException 
        }
   // }
   // catch (Exception e) {
   //     throw new Exception(e);
   // }
   }

   public void caricaPiuDi10() throws IndexOutOfBoundsException{
        int i;
        Punto p = new Punto (0,0);
        Cerchio c;
        for (i = 1 ; i<= 20 ; i++){
            c = new Cerchio (p,1,"bianco");
            this.elenco.add(i,c);
        }
   }
}
