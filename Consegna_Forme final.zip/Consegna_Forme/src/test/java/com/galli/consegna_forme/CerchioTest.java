/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author a.galli
 */
public class CerchioTest {
    
    @Test
    public void cerchioTest() {
        String esitoAtteso = "cerchio: centro:(0,0) raggio:5 colore:rosso";
        Punto p = new Punto (0,0);
        Cerchio c = new Cerchio(p,5,"rosso");
        String esitoEffettivo = c.toString();
        assertEquals("errore creatore Cerchio", esitoAtteso , esitoEffettivo );
    }
 
    @Test
    public void testTrasla(){
        Punto p0 = new Punto (-1,-3);
        Cerchio c = new Cerchio (p0 , 4, "blu");
        Punto p1 = new Punto(2,-1);
        c.trasla(3, 2);
        assertEquals ("errore metodo trasla" , p1.toString() , c.getPunto().toString());
    }
    
    
}
