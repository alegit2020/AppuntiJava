/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.galli.consegna_forme;

import static org.junit.Assert.*;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

/**
 *
 * @author a.galli
 */
public class GruppoDiFormeTest {
     @Test
     public void testTrasla_GruppoSemplice(){
        Punto pr = new Punto (1,1);
        Rettangolo r1 = new Rettangolo(pr , 5,7, "rosso");
        Punto pc = new Punto (-1,-3);
        Cerchio c1 = new Cerchio (pc , 4, "blu");
        GruppoDiForme g1 = new GruppoDiForme();
        g1.add(c1);
        g1.add(r1);
        Punto attesoRettangolo = new Punto (1,1);
        Punto attesoCerchio1 = new Punto (-1,-3);
        assertEquals("errore p1 vertice rettangolo", attesoRettangolo.toString() , r1.getPunto().toString() );
        assertEquals("errore p1 centro cerchio", attesoCerchio1.toString() , c1.getPunto().toString() );
        g1.trasla(3, 2);
        attesoRettangolo = new Punto (4,3);
        attesoCerchio1 = new Punto (2,-1);
        assertEquals("errore p1 traslazine rettangolo", attesoRettangolo.toString() , r1.getPunto().toString() );
        assertEquals("errore p1 traslazine cerchio", attesoCerchio1.toString() , c1.getPunto().toString() );
        
     }       
     
     @Test
     public void testTrasla_GruppoDiGruppi(){
        Punto pr = new Punto (1,1);
        Rettangolo r1 = new Rettangolo(pr , 5,7, "rosso");
        Punto pc = new Punto (-1,-3);
        Cerchio c1 = new Cerchio (pc , 4, "blu");
        GruppoDiForme g1 = new GruppoDiForme();
        g1.add(c1);
        g1.add(r1);
        
        pc = new Punto (-1,2);
        Cerchio c2 = new Cerchio (pc , 2, "blu");
        GruppoDiForme g2 = new GruppoDiForme();
        
        Punto attesoRettangolo = new Punto (1,1);
        Punto attesoCerchio1 = new Punto (-1,-3);
        Punto attesoCerchio2 = new Punto (-1,2);
     
        g2.add(c2);
        g2.add(g1);
        assertEquals("errore posizione gruppo g2", attesoCerchio2.toString() + attesoCerchio1.toString() + attesoRettangolo.toString() , g2.getPunto() );
        
        g2.trasla(3, 2);
        attesoRettangolo = new Punto (4,3);
        attesoCerchio1 = new Punto (2,-1);
        attesoCerchio2 = new Punto (2,4); //NOTA PER LA CORREZIONE: il testo indica erroneamente 2,3 come destinazione della traslazione
        assertEquals("errore traslazione gruppo g2", attesoCerchio2.toString() + attesoCerchio1.toString() + attesoRettangolo.toString() , g2.getPunto() );
     }      

     @Test //TEST per il comportamento con l'inserimento di meno di 10 elementi
        //ESITO ATTESO POSITIVO
     public void testMenoDi10 (){
        GruppoDiForme g = new GruppoDiForme(); 
        //Exception thrown;
         //thrown = assertDoesNotThrow(
           //      Exception.class,
             //    () -> g.caricaMenoDi10(),
               //  "Expected doThing() to throw, but it didn't"
         //);
         //thrown = assertDoesNotThrow( "messaggio" , {g.caricaMenoDi10();} );
         
         // NOTA PER CORREZIONE : non riesco ad usare il metodo assertDoesNotThrow
         //ma visto che prevedo di non generare Eccezioni può andar bene anche
         //la normale esecuzione...in caso contrario il @Test si interromperebbe
         //comunque se venisse generata una eccezione
         try {
             g.caricaMenoDi10();
         } catch (Exception e) {
             System.out.println("errore :non mi aspettavo venisse generata una eccezione");
         }
     }
       

     @Test //TEST per il comportamento con l'inserimento di meno di 10 elementi
        //ESITO ATTESO NEGATIVO
     public void testPiuDi10 (){
        GruppoDiForme g = new GruppoDiForme(); 
        Exception thrown = assertThrows(
                      Exception.class,
                          () -> g.caricaPiuDi10(),
                                 "errore: non è stata generata l'eccezione che mi aspettavo"
        );
        //eventuale codice per analizzare il msg di ritorno dall'eccezione
        //assertTrue(thrown.getMessage().contains("msg di ritorno")); 
     }
        
}
