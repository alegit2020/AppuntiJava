/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizio3;

/**
 *
 * @author alexg
 */
public abstract class AbstractForma implements Forma{
    protected String colore;
    protected int dimensione;
    
    @Override
    public String getColore() {
        return this.colore; 
    }

    @Override
    public int getDimensione() {
        return this.dimensione;
    }

    
    @Override
    public int hashCode(){
        int hash = 1;
        hash = 31 * hash + this.dimensione;
        hash = 31 * hash + this.colore.length();
        return hash;
    }


    @Override
    public boolean equals (Object obj) {
        if (this == obj) 
            return true;
        if (this == null)
            return false;
        if (this.getClass() != obj.getClass())
            return false;
        AbstractForma dummy = (AbstractForma) obj;
        if ( dummy.colore == this.colore && dummy.dimensione == this.dimensione)
            return true;
        return false;
    }
    
}
