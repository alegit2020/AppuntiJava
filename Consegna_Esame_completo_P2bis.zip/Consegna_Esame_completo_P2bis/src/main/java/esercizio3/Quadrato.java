package esercizio3;

import java.util.Objects;

/**
 *
 * @author alexg
 */
public class Quadrato extends AbstractForma{
   
    public Quadrato ( int d , String c){
        super.dimensione = d;
        super.colore = c;
    }
   
}
