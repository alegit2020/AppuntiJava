package esercizio3;

import java.util.Objects;

/**
 *
 * @author alexg
 */
public class Equilatero extends AbstractForma{

    public Equilatero ( int d , String c){
        super.dimensione = d;
        super.colore = c;
    }

}

