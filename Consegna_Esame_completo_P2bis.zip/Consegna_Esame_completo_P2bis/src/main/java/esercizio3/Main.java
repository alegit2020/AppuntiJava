/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizio3;

/**
 *
 * @author alexg
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Forma r1 = new Equilatero(1, "Rosso"); // r1 ed...
        Forma r2 = new Equilatero(1, "Rosso"); // ..r2 "contano" 1
        Forma r3 = new Quadrato(2, "Nero");
        Forma r4 = new Cerchio(2, "Nero");
        
        if (r1.equals(r2))
            System.out.println("pippo");
    }
    
}
