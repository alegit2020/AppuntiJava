package esercizio3;

import java.util.Objects;

/**
 *
 * @author alexg
 */
public class Cerchio extends AbstractForma{
   
    public Cerchio ( int d , String c){
        super.dimensione = d;
        super.colore = c;
    }

    
}
