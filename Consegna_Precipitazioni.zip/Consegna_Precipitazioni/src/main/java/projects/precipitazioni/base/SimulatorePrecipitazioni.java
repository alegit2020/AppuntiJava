package projects.precipitazioni.base;

import java.util.Scanner;

public class SimulatorePrecipitazioni {

	public static void main (String[] args){
                Scanner keyb;
		Precipitazioni p = new Precipitazioni();
		Visualizzatore vm = new VisualizzatoreMatrice();
		Visualizzatore vm1 = new VisualizzatoreMatrice();
		Visualizzatore vm2 = new VisualizzatoreMatrice2();
		Visualizzatore vm3 = new VisualizzatoreMatrice3();

                //Carico 10 posizioni dell'arrayList con una serie di Visualizzatori
                p.aggiungiVisualizzatore(vm1);
                p.aggiungiVisualizzatore(vm2);
                p.aggiungiVisualizzatore(vm3);
                p.aggiungiVisualizzatore(vm1);
                p.aggiungiVisualizzatore(vm2);
                p.aggiungiVisualizzatore(vm3);
                p.aggiungiVisualizzatore(vm1);
                p.aggiungiVisualizzatore(vm2);
                p.aggiungiVisualizzatore(vm3);
                p.aggiungiVisualizzatore(vm1);

                Integer i = -1;
                while (i== -1) {
                    try {
                        System.out.println("Scegli il visualizzatore da usare 1-10 :");
                        keyb = new Scanner(System.in);
                        i = keyb.nextInt();
                    } catch (Exception e) {
                        System.out.println("input errato...");
                    }
                }
                i = Math.abs(i);
                while (i>10) {
                    i = i / 10;
                }
                if (i>0) i=i-1;
                
                //uso il metodo con Overload
		p.setVisualizzatore(i);
                
                //p.setVisualizzatore(vm); // Chiamata originale
                
                p.eseguiSimulazione();
	}
}