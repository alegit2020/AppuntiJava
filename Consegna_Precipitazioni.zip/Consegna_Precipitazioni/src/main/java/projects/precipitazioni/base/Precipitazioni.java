package projects.precipitazioni.base;

import java.util.ArrayList;

public class Precipitazioni {

	private int[][] cartaPrecipitazioni;
	private Visualizzatore visualizzatore;
        private ArrayList<Visualizzatore> visList;
        
	public Precipitazioni () {
		this.cartaPrecipitazioni = new int[20][20];
                this.visList = new ArrayList();
	}

	int[][] getCartaPrecipitazioni() {
		return this.cartaPrecipitazioni;
	}

        public void aggiungiVisualizzatore(Visualizzatore v) {
            this.visList.add(v);
        }
        
        //faccio l'Overload che imposta il Visualizzatore in base ad un intero
        public void setVisualizzatore (int i) {
            this.visualizzatore = this.visList.get(i);
            this.visualizzatore.setPrecipitazioni(this);  //init dell OBJ precipitazioni
        }
        
	public void setVisualizzatore(Visualizzatore v) {
		this.visualizzatore = v;
		v.setPrecipitazioni(this);
	}

	public void notificaAggiornamento(int tempo) {
                System.out.println("\nNotifica Nativa:");
		this.visualizzatore.aggiornaSchermata(tempo);
/*
                Visualizzatore vAlt;
                System.out.println("\nNotifica Tipo1:");
                vAlt = (VisualizzatoreMatrice) this.visualizzatore;
		vAlt.aggiornaSchermata(tempo);

                System.out.println("\nNotifica Tipo2:");
                vAlt = (VisualizzatoreMatrice2) this.visualizzatore;
		vAlt.aggiornaSchermata(tempo);

                System.out.println("\nNotifica Tipo3:");
                vAlt = (VisualizzatoreMatrice3) this.visualizzatore;
		vAlt.aggiornaSchermata(tempo);
*/
}

	private void calcolaPrecipitazioni(int istanteTemporale){
		for (int i=0; i<this.cartaPrecipitazioni.length; i++)
			for (int j=0; j<this.cartaPrecipitazioni[i].length; j++)
				this.cartaPrecipitazioni[i][j] = (int)(Math.random()*10);
		try { Thread.sleep( 100); }
		catch( InterruptedException e ) {
			e.printStackTrace();
		}
	}

	public void eseguiSimulazione() {
		for (int tempo=0; tempo<100; tempo++) {
			this.calcolaPrecipitazioni(tempo);
			this.notificaAggiornamento(tempo);
		}
	}
}