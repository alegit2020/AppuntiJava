/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projects.precipitazioni.base;

/**
 *
 * @author alexg
 */
public class VisualizzatoreMatrice2 implements Visualizzatore{

	private Precipitazioni precipitazioni;

    @Override
	public void setPrecipitazioni (Precipitazioni p) {
		precipitazioni = p;
	}

    @Override
	public void aggiornaSchermata(int passo) {
		System.out.println("Passo " + passo);
		for (int i=0; i<precipitazioni.getCartaPrecipitazioni().length; i++) {
			for (int j=0; j<precipitazioni.getCartaPrecipitazioni()[i].length; j++)
				System.out.print("/" + precipitazioni.getCartaPrecipitazioni()[i][j]+" ");
			System.out.println();
		}
	}
}

